# Lab summary — session 20261013T182312Z

| check | Keycloak 26.7.0 | Keycloak 26.8.0 |
|---|---|---|
| 01 stock-compatibility | 1/1 PASS | 1/1 PASS |
| 02 causality | 1/1 PASS | 1/1 PASS |
| 03 provider-hook | 1/1 PASS | 1/1 PASS |
| 04 negative-controls | 1/1 PASS | 1/1 PASS |
| 05 extension-real-documents | 1/1 PASS | 1/1 PASS |
| 06 two-doors | 1/1 PASS | 1/1 PASS |
| 07 advertisement | 1/1 PASS | 1/1 PASS |
| 08 cimd-only-posture | 1/1 PASS | 1/1 PASS |
| 09 ipv6-allowlist | 1/1 PASS | 1/1 PASS |
| 10 eight-in-one-run | 1/1 PASS | 1/1 PASS |

Attempts that ended NOT RUN [vendor-fetch] and were tried again: 1
- 20261013T182312Z-v26.7.0-c08-r1-a1: NOT RUN [vendor-fetch]: not fetched by Keycloak (network): lab-cimd-only-lenient copilot-cli

Problems: 0
